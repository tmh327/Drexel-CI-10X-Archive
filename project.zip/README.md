# Drexel-CI-Archive
Archive of Drexel CI10X track students' projects.
This is a web application that will allow students and faculties to upload their projects, search and browse through previous students projects from other academic years.
This web application will be built using a Flask Framework with SQLite3.

REQUIREMENTS -- modules:
flask_login
forms
wtforms
email_validator

COMPILATION:
through terminal:
py run.py runserver -d

Web application is also live at: 10.246.250.148:9917 on Drexel VPN